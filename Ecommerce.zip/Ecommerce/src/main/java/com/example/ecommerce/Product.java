package com.example.ecommerce;

import javafx.beans.property.SimpleIntegerProperty;

public class Product {
    private SimpleIntegerProperty id;
    private SimpleIntegerProperty name;
    private  SimpleIntegerProperty price;

    public Product(int id, Sting name, Double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public int getId() {
        return id.get();
    }

    public SimpleIntegerProperty idProperty() {
        return id;
    }

    public int getName() {
        return name.get();
    }

    public SimpleIntegerProperty nameProperty() {
        return name;
    }

    public int getPrice() {
        return price.get();
    }

    public SimpleIntegerProperty priceProperty() {
        return price;
    }
}
