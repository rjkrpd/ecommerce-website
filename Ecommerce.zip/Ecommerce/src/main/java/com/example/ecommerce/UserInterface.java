package com.example.ecommerce;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class UserInterface {
    GridPane loginPage;
    HBox headerBar;
    Customer loggedInCustomer;


    public BorderPane createContent() {
        BorderPane root = new BorderPane();
        root.setPrefSize(600,400);
        root.setTop(headerBar);
        root.setCenter(loginPage);
        return root;
    }

    public  UserInterface()
    {
        createLoginPage();
        createHeaderBar();
    }


        private void createLoginPage() {
            Text userNameText = new Text("User Name");
            Text passwordText = new Text("Password");

            TextField userName = new TextField();
            userName.setPromptText("enter your username");
            PasswordField password = new PasswordField();
            password.setPromptText("enter your password");
            Label messageLabel =new Label("hi");
            Button loginButton = new Button("login");

            loginPage = new GridPane();
            loginPage.setAlignment(Pos.CENTER);
            loginPage.setHgap(10);
            loginPage.setVgap(10);
            loginPage.add(userNameText, 0, 0);
            loginPage.add(userName, 1, 0);
            loginPage.add(passwordText, 0, 1);
            loginPage.add(password, 1, 1);
            loginPage.add(loginButton,1,2);
            loginPage.add(messageLabel, 1,3);
            loginButton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    String name= userName.getText();
                    String pass= password.getText();
                    Login login=new Login();
                    loggedInCustomer= login.customerLogin(name , pass);

                }
            });
        }
        private void createHeaderBar(){
        TextField searchBar=new TextField();
        searchBar.setPromptText("search here");
        searchBar.setPrefWidth(280);


        Button searchButton= new Button("search");
        headerBar = new HBox();
//        headerBar.setStyle("-fx-background-color:grey;");
        headerBar.setPadding(new Insets(10));
        headerBar.setSpacing(10);
        headerBar.setAlignment(Pos.CENTER);
        headerBar.getChildren().addAll(searchBar, searchButton);

        }
}








